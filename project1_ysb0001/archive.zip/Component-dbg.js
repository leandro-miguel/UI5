sap.ui.define(['sap/suite/ui/generic/template/lib/AppComponent'], function(AppComponent) {
    return AppComponent.extend("project1ysb0001.Component", {
        metadata: {
            manifest: "json"
        }
    });
});
